/*
 * ╔══════════════════════════════════════════════════════════╗
 * ║     BRAS ROBOTIQUE — Client Simple                       ║
 * ║     Compile : gcc -o bras bras.c -lpthread               ║
 * ║     Execute : ./bras 1      (bras numéro 1)              ║
 * ║               ./bras 2      (bras numéro 2)              ║
 * ╚══════════════════════════════════════════════════════════╝
 *
 * Chaque bras a 3 threads :
 *   Thread 1 — Réflexion  : pense pendant 1-3 secondes
 *   Thread 2 — Demande    : demande 2 outils au serveur
 *   Thread 3 — Assemblage : travaille 2-4 sec puis libère
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <time.h>
#include <stdarg.h>

#define PORT    9090
#define NB_OT   5
#define BUF     256

/* ── Couleurs ── */
#define RESET   "\033[0m"
#define BOLD    "\033[1m"
#define CYAN    "\033[1;36m"
#define GREEN   "\033[1;32m"
#define YELLOW  "\033[1;33m"
#define MAGENTA "\033[1;35m"
#define RED     "\033[1;31m"
#define DIM     "\033[2m"
#define WHITE   "\033[1;37m"

/* ── Variables globales du bras ── */
static int bras_id;
static int sock;
static int outil1, outil2;

static int pret      = 0;  /* réflexion → demande */
static int assembler = 0;  /* demande → assemblage */

static pthread_mutex_t mutex  = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  c_pret = PTHREAD_COND_INITIALIZER;
static pthread_cond_t  c_asm  = PTHREAD_COND_INITIALIZER;

/* ════════════════════════════════════
 *  Journalisation horodatée
 * ════════════════════════════════════ */
void log_b(const char *couleur, const char *icone, const char *msg) {
    time_t t = time(NULL);
    struct tm *tm = localtime(&t);
    printf("%s[%02d:%02d:%02d]%s %s%s Bras %d%s → %s\n",
           DIM, tm->tm_hour, tm->tm_min, tm->tm_sec, RESET,
           couleur, icone, bras_id, RESET, msg);
    fflush(stdout);
}

void log_bf(const char *couleur, const char *icone, const char *fmt, ...) {
    char buf[256];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    log_b(couleur, icone, buf);
}


/* ════════════════════════════════════
 *  Thread 1 : Réflexion
 *  Pense 1-3 sec puis signale qu'il est prêt
 * ════════════════════════════════════ */
void* thread_reflexion(void *arg) {
    (void)arg;
    while (1) {
        int duree = rand() % 3 + 1;
        log_bf(CYAN, "💭", "En réflexion pendant %d sec...", duree);
        sleep(duree);

        pthread_mutex_lock(&mutex);
        while (assembler)                   /* attendre fin assemblage */
            pthread_cond_wait(&c_asm, &mutex);
        pret = 1;
        pthread_cond_signal(&c_pret);       /* réveiller thread demande */
        pthread_mutex_unlock(&mutex);
    }
    return NULL;
}

/* ════════════════════════════════════
 *  Thread 2 : Demande d'outils
 *  Choisit 2 outils et les demande au serveur
 * ════════════════════════════════════ */
void* thread_demande(void *arg) {
    (void)arg;
    char msg[BUF], rep[BUF];

    while (1) {
        /* Attendre signal de réflexion */
        pthread_mutex_lock(&mutex);
        while (!pret)
            pthread_cond_wait(&c_pret, &mutex);
        pret = 0;
        pthread_mutex_unlock(&mutex);

        /* Choisir 2 outils distincts */
        outil1 = rand() % NB_OT;
        do { outil2 = rand() % NB_OT; } while (outil2 == outil1);

        log_bf(YELLOW, "📤", "Demande outils O%d et O%d au serveur...", outil1, outil2);

        /* Envoyer demande */
        snprintf(msg, BUF, "DEMANDE %d %d", outil1, outil2);
        send(sock, msg, strlen(msg), 0);

        /* Lire 2 réponses OK (une par outil) */
        memset(rep, 0, BUF);
        recv(sock, rep, BUF-1, 0);
        memset(rep, 0, BUF);
        recv(sock, rep, BUF-1, 0);

        log_bf(GREEN, "✅", "Outils obtenus ! Début de l'assemblage...");

        /* Signaler au thread assemblage */
        pthread_mutex_lock(&mutex);
        assembler = 1;
        pthread_cond_signal(&c_asm);
        pthread_mutex_unlock(&mutex);
    }
    return NULL;
}

/* ════════════════════════════════════
 *  Thread 3 : Assemblage
 *  Travaille 2-4 sec puis libère les outils
 * ════════════════════════════════════ */
void* thread_assemblage(void *arg) {
    (void)arg;
    char msg[BUF];

    while (1) {
        /* Attendre signal de demande */
        pthread_mutex_lock(&mutex);
        while (!assembler)
            pthread_cond_wait(&c_asm, &mutex);
        int o1 = outil1, o2 = outil2;
        pthread_mutex_unlock(&mutex);

        int duree = rand() % 3 + 2;
        log_bf(MAGENTA, "🔨", "Assemblage avec O%d et O%d (%d sec)...", o1, o2, duree);
        sleep(duree);

        /* Libérer outil 1 */
        snprintf(msg, BUF, "LIBERE %d", o1);
        send(sock, msg, strlen(msg), 0);
        memset(msg, 0, BUF);
        recv(sock, msg, BUF-1, 0);

        /* Libérer outil 2 */
        snprintf(msg, BUF, "LIBERE %d", o2);
        send(sock, msg, strlen(msg), 0);
        memset(msg, 0, BUF);
        recv(sock, msg, BUF-1, 0);

        log_bf(GREEN, "✔", "Tâche terminée ! Outils O%d et O%d libérés.", o1, o2);

        /* Signaler fin à réflexion */
        pthread_mutex_lock(&mutex);
        assembler = 0;
        pthread_cond_signal(&c_asm);
        pthread_mutex_unlock(&mutex);
    }
    return NULL;
}

/* ════════════════════════════════════
 *  Main
 * ════════════════════════════════════ */
int main(int argc, char *argv[]) {
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <numero_bras>\n", argv[0]);
        fprintf(stderr, "Ex:    ./bras 1\n");
        return 1;
    }

    bras_id = atoi(argv[1]);
    srand(time(NULL) + bras_id * 17);

    printf("\n" BOLD WHITE);
    printf("╔══════════════════════════════════════════════════════╗\n");
    printf("║              BRAS ROBOTIQUE N° %-3d                   ║\n", bras_id);
    printf("║         3 threads : réflexion/demande/assemblage     ║\n");
    printf("╚══════════════════════════════════════════════════════╝\n\n" RESET);

    /* Connexion au serveur */
    sock = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in serv = {
        .sin_family = AF_INET,
        .sin_port   = htons(PORT)
    };
    inet_pton(AF_INET, "127.0.0.1", &serv.sin_addr);

    if (connect(sock, (struct sockaddr*)&serv, sizeof(serv)) < 0) {
        fprintf(stderr, RED "✖ Impossible de se connecter. Le serveur est-il lancé ?\n" RESET);
        return 1;
    }
    log_b(GREEN, "🔗", "Connecté au serveur !");

    /* Démarrer les 3 threads */
    pthread_t t1, t2, t3;
    pthread_create(&t1, NULL, thread_reflexion, NULL);
    pthread_create(&t2, NULL, thread_demande,   NULL);
    pthread_create(&t3, NULL, thread_assemblage, NULL);

    pthread_join(t1, NULL);
    pthread_join(t2, NULL);
    pthread_join(t3, NULL);

    close(sock);
    return 0;
}
