/*
 * ╔══════════════════════════════════════════════════╗
 * ║     GESTIONNAIRE D'OUTILS — Serveur Simple       ║
 * ║     Compile : gcc -o serveur serveur.c -lpthread ║
 * ║     Execute : ./serveur                          ║
 * ╚══════════════════════════════════════════════════╝
 *
 * Serveur TCP qui gère 5 outils partagés entre bras robotiques.
 * Anti-deadlock : outils toujours acquis dans l'ordre croissant.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <time.h>

#define PORT        9090
#define NB_OUTILS   5
#define NB_BRAS_MAX 8
#define BUF         256

/* ── Couleurs ── */
#define RESET   "\033[0m"
#define BOLD    "\033[1m"
#define CYAN    "\033[1;36m"
#define GREEN   "\033[1;32m"
#define YELLOW  "\033[1;33m"
#define RED     "\033[1;31m"
#define MAGENTA "\033[1;35m"
#define DIM     "\033[2m"
#define WHITE   "\033[1;37m"

/* ── Outil partagé ── */
typedef struct {
    int id;
    int libre;
    int bras;          /* bras qui le tient, -1 si libre */
    pthread_mutex_t m;
    pthread_cond_t  dispo;
} Outil;

static Outil outils[NB_OUTILS];
static int   nb_connexions = 0;
static pthread_mutex_t m_log = PTHREAD_MUTEX_INITIALIZER;

/* ════════════════════════════════════
 *  Journalisation horodatée avec couleur
 * ════════════════════════════════════ */
void log_s(const char *couleur, const char *icone, const char *msg) {
    time_t t = time(NULL);
    struct tm *tm = localtime(&t);
    pthread_mutex_lock(&m_log);
    printf("%s[%02d:%02d:%02d]%s %s%s%s %s\n",
           DIM, tm->tm_hour, tm->tm_min, tm->tm_sec, RESET,
           couleur, icone, RESET, msg);
    fflush(stdout);
    pthread_mutex_unlock(&m_log);
}

void log_sf(const char *couleur, const char *icone, const char *fmt, ...) {
    char buf[256];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    log_s(couleur, icone, buf);
}

/* ════════════════════════════════════
 *  Afficher l'état des outils
 * ════════════════════════════════════ */
void afficher_etat_outils() {
    pthread_mutex_lock(&m_log);
    printf("\n  " BOLD "État des outils : " RESET);
    for (int i = 0; i < NB_OUTILS; i++) {
        if (outils[i].libre)
            printf(GREEN "  🔧 O%d:libre  " RESET, i);
        else
            printf(RED   "  🔒 O%d:Bras%-2d" RESET, i, outils[i].bras);
    }
    printf("\n\n");
    fflush(stdout);
    pthread_mutex_unlock(&m_log);
}

/* ════════════════════════════════════
 *  Acquérir un outil (bloquant)
 * ════════════════════════════════════ */
void acquerir(int outil_id, int bras_id) {
    Outil *o = &outils[outil_id];
    pthread_mutex_lock(&o->m);
    while (!o->libre) {
        log_sf(YELLOW, "⏳", "Bras %d attend outil O%d...", bras_id, outil_id);
        pthread_cond_wait(&o->dispo, &o->m);
    }
    o->libre = 0;
    o->bras  = bras_id;
    pthread_mutex_unlock(&o->m);
    log_sf(GREEN, "✅", "Bras %d obtient outil O%d", bras_id, outil_id);
    afficher_etat_outils();
}

/* ════════════════════════════════════
 *  Libérer un outil
 * ════════════════════════════════════ */
void liberer(int outil_id) {
    Outil *o = &outils[outil_id];
    pthread_mutex_lock(&o->m);
    int bras = o->bras;
    o->libre = 1;
    o->bras  = -1;
    pthread_cond_signal(&o->dispo);
    pthread_mutex_unlock(&o->m);
    log_sf(MAGENTA, "🔓", "Bras %d libère outil O%d", bras, outil_id);
    afficher_etat_outils();
}

/* ════════════════════════════════════
 *  Thread par bras connecté
 * ════════════════════════════════════ */

void* handle_bras(void *arg) {
    int sock    = *(int*)arg;
    free(arg);
    int bras_id = ++nb_connexions;
    char buf[BUF];

    log_sf(CYAN, "🤖", "Bras %d connecté (socket %d)", bras_id, sock);

    while (1) {
        memset(buf, 0, BUF);
        int r = recv(sock, buf, BUF-1, 0);
        if (r <= 0) break;
        buf[r] = '\0';

        int id1, id2;
        if (sscanf(buf, "DEMANDE %d %d", &id1, &id2) == 2) {
            /* Anti-deadlock : ordre croissant */
            if (id1 > id2) { int tmp=id1; id1=id2; id2=tmp; }
            log_sf(CYAN, "📩", "Bras %d demande outils O%d et O%d", bras_id, id1, id2);
            acquerir(id1, bras_id);
            acquerir(id2, bras_id);
            send(sock, "OK", 2, 0);

        } else if (sscanf(buf, "LIBERE %d", &id1) == 1) {
            liberer(id1);
            send(sock, "OK", 2, 0);
        }
    }

    log_sf(RED, "👋", "Bras %d déconnecté", bras_id);
    close(sock);
    return NULL;
}

/* ════════════════════════════════════
 *  Main
 * ════════════════════════════════════ */
int main() {
    /* Init outils */
    for (int i = 0; i < NB_OUTILS; i++) {
        outils[i].id   = i;
        outils[i].libre = 1;
        outils[i].bras  = -1;
        pthread_mutex_init(&outils[i].m, NULL);
        pthread_cond_init(&outils[i].dispo, NULL);
    }

    printf("\n" BOLD WHITE);
    printf("╔══════════════════════════════════════════════════════╗\n");
    printf("║         SERVEUR GESTIONNAIRE D'OUTILS                ║\n");
    printf("║              Entrepôt Intelligent                    ║\n");
    printf("╚══════════════════════════════════════════════════════╝\n" RESET);
    printf("\n  " GREEN "✔" RESET " %d outils initialisés\n", NB_OUTILS);
    printf("  " GREEN "✔" RESET " Port : %d\n", PORT);
    printf("  " GREEN "✔" RESET " Max bras : %d\n\n", NB_BRAS_MAX);
    afficher_etat_outils();

    int srv = socket(AF_INET, SOCK_STREAM, 0);
    int opt = 1;
    setsockopt(srv, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    struct sockaddr_in addr = {
        .sin_family      = AF_INET,
        .sin_addr.s_addr = INADDR_ANY,
        .sin_port        = htons(PORT)
    };
    bind(srv, (struct sockaddr*)&addr, sizeof(addr));
    listen(srv, NB_BRAS_MAX);

    log_s(GREEN, "🚀", "Serveur démarré — en attente de bras...");

    while (1) {
        int *s = malloc(sizeof(int));
        *s = accept(srv, NULL, NULL);
        if (*s < 0) { free(s); continue; }
        pthread_t tid;
        pthread_create(&tid, NULL, handle_bras, s);
        pthread_detach(tid);
    }

    close(srv);
    return 0;
}
