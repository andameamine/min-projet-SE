/*
 * ╔══════════════════════════════════════════════════╗
 * ║     ORDONNANCEUR DE PROCESSUS — Exemple Simple   ║
 * ║     Compile : gcc -o ordo ordo.c                 ║
 * ║     Execute : ./ordo                             ║
 * ╚══════════════════════════════════════════════════╝
 *
 * 3 politiques intégrées : FIFO, SJF, Round Robin
 * 4 processus avec bursts CPU simulés tick par tick
 */

#include <stdio.h>
#include <string.h>

/* ── États des processus ── */
#define NOUVEAU   0
#define PRET      1
#define EN_COURS  2
#define TERMINE   3

/* ── Quantum Round Robin ── */
#define QUANTUM 3

/* ── Couleurs terminal ── */
#define RESET   "\033[0m"
#define BOLD    "\033[1m"
#define CYAN    "\033[1;36m"
#define GREEN   "\033[1;32m"
#define YELLOW  "\033[1;33m"
#define RED     "\033[1;31m"
#define MAGENTA "\033[1;35m"
#define BLUE    "\033[1;34m"
#define WHITE   "\033[1;37m"
#define DIM     "\033[2m"

/* ── Structure Processus ── */
typedef struct {
    char nom[8];
    int  arrivee;
    int  burst;       /* durée CPU totale */
    int  restant;     /* temps CPU restant */
    int  etat;
    int  debut;       /* 1er tick d'exécution */
    int  fin;         /* tick de fin */
    int  attente;     /* temps passé en PRET */
} Processus;

/* ════════════════════════════════════
 *  Affichage
 * ════════════════════════════════════ */
void ligne_separatrice() {
    printf(DIM "  ├────┼──────────┼─────────────────────────────────────────────┤\n" RESET);
}

void entete_tableau() {
    printf("\n");
    printf(CYAN "  ┌────┬──────────┬─────────────────────────────────────────────┐\n");
    printf("  │ t  │ Processus│ Action                                      │\n");
    printf("  ├────┼──────────┼─────────────────────────────────────────────┤\n" RESET);
}

void pied_tableau() {
    printf(CYAN "  └────┴──────────┴─────────────────────────────────────────────┘\n" RESET);
}

/* ════════════════════════════════════
 *  Politique FIFO
 * ════════════════════════════════════ */
Processus* fifo(Processus *list, int n) {
    Processus *choix = NULL;
    for (int i = 0; i < n; i++) {
        if (list[i].etat == PRET) {
            if (!choix || list[i].arrivee < choix->arrivee)
                choix = &list[i];
        }
    }
    return choix;
}

/* ════════════════════════════════════
 *  Politique SJF
 * ════════════════════════════════════ */
Processus* sjf(Processus *list, int n) {
    Processus *choix = NULL;
    for (int i = 0; i < n; i++) {
        if (list[i].etat == PRET) {
            if (!choix || list[i].restant < choix->restant)
                choix = &list[i];
        }
    }
    return choix;
}

/* ════════════════════════════════════
 *  Politique Round Robin
 * ════════════════════════════════════ */
static int rr_index   = 0;
static int rr_utilise = 0;

Processus* round_robin(Processus *list, int n) {
    if (rr_utilise >= QUANTUM) {
        rr_utilise = 0;
        rr_index   = (rr_index + 1) % n;
    }
    for (int i = 0; i < n; i++) {
        int idx = (rr_index + i) % n;
        if (list[idx].etat == PRET) {
            if (i != 0) { rr_index = idx; rr_utilise = 0; }
            rr_utilise++;
            return &list[idx];
        }
    }
    rr_utilise = 0;
    return NULL;
}

/* ════════════════════════════════════
 *  Simulation principale
 * ════════════════════════════════════ */
void simuler(Processus *procs, int n, const char *nom_politique,
             Processus* (*politique)(Processus*, int)) {

    /* Réinitialiser */
    rr_index = 0; rr_utilise = 0;
    for (int i = 0; i < n; i++) {
        procs[i].etat    = NOUVEAU;
        procs[i].restant = procs[i].burst;
        procs[i].debut   = -1;
        procs[i].fin     = -1;
        procs[i].attente = 0;
    }

    printf("\n");
    printf(BOLD WHITE "╔══════════════════════════════════════════════════════╗\n");
    printf("║  Politique : %-38s║\n", nom_politique);
    printf("╚══════════════════════════════════════════════════════╝\n" RESET);

    entete_tableau();

    int t = 0, max_t = 200;
    int tous_termines = 0;

    while (!tous_termines && t < max_t) {
        /* Faire arriver les processus */
        for (int i = 0; i < n; i++)
            if (procs[i].etat == NOUVEAU && procs[i].arrivee == t) {
                procs[i].etat = PRET;
                printf(DIM "  │ %2d │ %-8s │ ► Arrivée dans la file                       │\n" RESET,
                       t, procs[i].nom);
            }

        /* Choisir un processus */
        Processus *p = politique(procs, n);

        if (p) {
            if (p->debut == -1) p->debut = t;
            p->etat = EN_COURS;
            p->restant--;

            /* Couleur selon processus */
            const char *col = GREEN;
            if      (strcmp(p->nom,"P2")==0) col = YELLOW;
            else if (strcmp(p->nom,"P3")==0) col = MAGENTA;
            else if (strcmp(p->nom,"P4")==0) col = BLUE;

            printf("  │ %2d │ %s%-8s%s │ ▶ CPU  [", t, col, p->nom, RESET);
            /* Barre de progression */
            int total = p->burst, fait = total - p->restant;
            for (int k = 0; k < total; k++)
                printf("%s%s", k < fait ? "█" : "░", RESET);
            printf("] %d/%d restant", fait, total);

            /* Padding */
            int pad = 12 - total;
            for (int k = 0; k < pad; k++) printf(" ");
            printf("  │\n");

            if (p->restant == 0) {
                p->fin  = t + 1;
                p->etat = TERMINE;
                printf("  │ %2d │ %s%-8s%s │ " GREEN "✔ TERMINÉ" RESET "                                  │\n",
                       t, col, p->nom, RESET);
                ligne_separatrice();
            }
        } else {
            printf(DIM "  │ %2d │ [idle]   │ zzz CPU libre...                             │\n" RESET, t);
        }

        /* Compter l'attente */
        for (int i = 0; i < n; i++)
            if (procs[i].etat == PRET) procs[i].attente++;

        /* Vérifier si tout est terminé */
        tous_termines = 1;
        for (int i = 0; i < n; i++)
            if (procs[i].etat != TERMINE && procs[i].etat != NOUVEAU)
                tous_termines = 0;
        /* Vérifier aussi si des processus n'ont pas encore arrivé */
        for (int i = 0; i < n; i++)
            if (procs[i].etat == NOUVEAU) tous_termines = 0;

        t++;
    }

    pied_tableau();

    /* Statistiques */
    printf("\n" BOLD CYAN "  📊 STATISTIQUES\n" RESET);
    printf(CYAN "  ┌──────────┬──────────┬──────────┬──────────┬──────────┐\n");
    printf("  │ Proc     │ Arrivée  │ Burst    │ Attente  │ Retour   │\n");
    printf("  ├──────────┼──────────┼──────────┼──────────┼──────────┤\n" RESET);

    double moy_att = 0, moy_ret = 0;
    for (int i = 0; i < n; i++) {
        int retour = procs[i].fin - procs[i].arrivee;
        moy_att += procs[i].attente;
        moy_ret += retour;

        const char *col = GREEN;
        if      (strcmp(procs[i].nom,"P2")==0) col = YELLOW;
        else if (strcmp(procs[i].nom,"P3")==0) col = MAGENTA;
        else if (strcmp(procs[i].nom,"P4")==0) col = BLUE;

        printf("  │ %s%-8s%s │ %8d │ %8d │ %8d │ %8d │\n",
               col, procs[i].nom, RESET,
               procs[i].arrivee, procs[i].burst,
               procs[i].attente, retour);
    }
    printf(CYAN "  ├──────────┼──────────┼──────────┼──────────┼──────────┤\n");
    printf("  │ " RESET BOLD "Moyenne   " CYAN "│          │          │ %8.1f │ %8.1f │\n" RESET,
           moy_att/n, moy_ret/n);
    printf(CYAN "  └──────────┴──────────┴──────────┴──────────┴──────────┘\n\n" RESET);
}

/* ════════════════════════════════════
 *  Main
 * ════════════════════════════════════ */
int main() {
    /* 4 processus simples */
    Processus procs[] = {
        {"P1", 0, 5},
        {"P2", 1, 3},
        {"P3", 2, 8},
        {"P4", 3, 2},
    };
    int n = 4;

    printf("\n" BOLD WHITE);
    printf("╔══════════════════════════════════════════════════════╗\n");
    printf("║         SIMULATION ORDONNANCEUR DE PROCESSUS         ║\n");
    printf("║                   Projet SE — ENSEM                  ║\n");
    printf("╚══════════════════════════════════════════════════════╝\n" RESET);
    printf("\n  Processus chargés :\n");
    printf(DIM "  ┌──────────┬──────────┬──────────┐\n");
    printf("  │ Nom      │ Arrivée  │ Burst CPU│\n");
    printf("  ├──────────┼──────────┼──────────┤\n" RESET);
    for (int i = 0; i < n; i++) {
        const char *col = GREEN;
        if      (strcmp(procs[i].nom,"P2")==0) col = YELLOW;
        else if (strcmp(procs[i].nom,"P3")==0) col = MAGENTA;
        else if (strcmp(procs[i].nom,"P4")==0) col = BLUE;
        printf("  │ %s%-8s%s │ %8d │ %8d │\n",
               col, procs[i].nom, RESET, procs[i].arrivee, procs[i].burst);
    }
    printf(DIM "  └──────────┴──────────┴──────────┘\n" RESET);

    printf("\n" BOLD "  Choisir une politique :\n" RESET);
    printf("    " GREEN "1" RESET " → FIFO        (Premier arrivé, premier servi)\n");
    printf("    " YELLOW "2" RESET " → SJF         (Plus court en premier)\n");
    printf("    " MAGENTA "3" RESET " → Round Robin (Quantum = %d)\n", QUANTUM);
    printf("    " CYAN "4" RESET " → Toutes les politiques\n");
    printf("\n  Votre choix [1-4] : ");

    int choix = 1;
    scanf("%d", &choix);

    if (choix == 1 || choix == 4)
        simuler(procs, n, "FIFO — Premier arrivé, premier servi", fifo);
    if (choix == 2 || choix == 4)
        simuler(procs, n, "SJF  — Plus court en premier", sjf);
    if (choix == 3 || choix == 4)
        simuler(procs, n, "Round Robin — Quantum = 3", round_robin);

    printf(BOLD GREEN "  Simulation terminée.\n\n" RESET);
    return 0;
}
